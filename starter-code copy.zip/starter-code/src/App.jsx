import React from "react";

function App() {
  return (
    <div>
      <h2>GA SEI</h2>
    </div>
  );
}

export default App;
